(() => {
  "use strict";

  const STORAGE_KEY = "areev_sales_manager_v1";
  const $ = (id) => document.getElementById(id);
  const todayISO = () => {
    const now = new Date();
    const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 10);
  };
  const makeId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const initialData = () => ({
    profile: { business: "", name: "", phone: "", currency: "INR" },
    products: [],
    customers: [],
    sales: []
  });

  let data = loadData();
  let cart = [];
  let toastTimer;

  function loadData() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return initialData();
      const parsed = JSON.parse(saved);
      return {
        profile: { ...initialData().profile, ...(parsed.profile || {}) },
        products: Array.isArray(parsed.products) ? parsed.products : [],
        customers: Array.isArray(parsed.customers) ? parsed.customers : [],
        sales: Array.isArray(parsed.sales) ? parsed.sales : []
      };
    } catch (error) {
      console.error("Could not load saved app data:", error);
      return initialData();
    }
  }

  function saveData() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error("Could not save app data:", error);
      showToast("Could not save data. Check browser storage space.");
      return false;
    }
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[character]));
  }

  function money(value) {
    const currency = data.profile.currency || "INR";
    try {
      return new Intl.NumberFormat("en-IN", {
        style: "currency", currency, maximumFractionDigits: 2
      }).format(Number(value) || 0);
    } catch {
      return `₹${(Number(value) || 0).toFixed(2)}`;
    }
  }

  function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
  }

  function formatDate(dateString) {
    if (!dateString) return "—";
    const date = new Date(`${dateString}T00:00:00`);
    return Number.isNaN(date.getTime()) ? dateString : date.toLocaleDateString();
  }

  function getCustomerName(id) {
    if (!id) return "Walk-in customer";
    return data.customers.find((customer) => customer.id === id)?.name || "Deleted customer";
  }

  function setPage(page) {
    document.querySelectorAll(".page").forEach((element) => element.classList.remove("active"));
    document.querySelectorAll(".nav-link").forEach((element) => element.classList.toggle("active", element.dataset.page === page));
    const pageElement = $(`page-${page}`);
    if (!pageElement) return;
    pageElement.classList.add("active");
    $("pageTitle").textContent = page.charAt(0).toUpperCase() + page.slice(1);
    $("sidebar").classList.remove("open");
    if (page === "dashboard") renderDashboard();
    if (page === "products") renderProducts();
    if (page === "customers") renderCustomers();
    if (page === "sales") renderSalePage();
    if (page === "reports") renderReports();
    if (page === "settings") renderSettings();
  }

  function renderHeader() {
    $("todayDate").textContent = new Date().toLocaleDateString(undefined, {
      weekday: "long", day: "numeric", month: "long", year: "numeric"
    });
    $("profileName").textContent = data.profile.business || data.profile.name || "My Business";
    $("profileShortcut").textContent = (data.profile.name || data.profile.business || "A").trim().charAt(0).toUpperCase();
  }

  function renderDashboard() {
    const todaySales = data.sales.filter((sale) => sale.date === todayISO());
    const todayTotal = todaySales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);
    const allTotal = data.sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);
    const stock = data.products.reduce((sum, product) => sum + Number(product.stock || 0), 0);
    $("statToday").textContent = money(todayTotal);
    $("statTodayCount").textContent = `${todaySales.length} transactions`;
    $("statAll").textContent = money(allTotal);
    $("statProducts").textContent = String(data.products.length);
    $("statStock").textContent = `${stock} units in stock`;
    $("statCustomers").textContent = String(data.customers.length);

    const recent = [...data.sales].sort((a, b) => b.createdAt - a.createdAt).slice(0, 6);
    $("recentSales").innerHTML = recent.length ? tableHTML(
      ["Date", "Customer", "Items", "Total"],
      recent.map((sale) => [
        formatDate(sale.date), escapeHTML(getCustomerName(sale.customerId)),
        sale.items.reduce((sum, item) => sum + Number(item.quantity), 0),
        money(sale.total)
      ])
    ) : emptyHTML("No sales recorded yet.");
    const low = data.products.filter((product) => Number(product.stock) <= 5);
    $("lowStockList").innerHTML = low.length
      ? low.map((product) => `<div class="picker-item"><div><strong>${escapeHTML(product.name)}</strong><span>${Number(product.stock)} units left</span></div><span class="pill low">Low stock</span></div>`).join("")
      : emptyHTML("No low-stock products.");
  }

  function tableHTML(headers, rows) {
    return `<table><thead><tr>${headers.map((header) => `<th>${header}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
  }

  function emptyHTML(message) {
    return `<div class="empty-state">${escapeHTML(message)}</div>`;
  }

  function renderProducts() {
    const query = $("productSearch").value.trim().toLowerCase();
    const products = data.products.filter((product) => product.name.toLowerCase().includes(query));
    $("productCount").textContent = `${products.length} product(s)`;
    $("productsTable").innerHTML = products.length ? tableHTML(
      ["Product", "Selling price", "Available stock", "Status", "Actions"],
      products.map((product) => [
        `<strong>${escapeHTML(product.name)}</strong>`,
        money(product.price),
        Number(product.stock),
        Number(product.stock) <= 5 ? '<span class="pill low">Low stock</span>' : '<span class="pill">In stock</span>',
        `<div class="table-actions"><button class="small-action" data-action="edit-product" data-id="${product.id}">Edit</button><button class="small-action delete" data-action="delete-product" data-id="${product.id}">Delete</button></div>`
      ])
    ) : emptyHTML("No products found. Add your first product.");
  }

  function openProductDialog(product = null) {
    $("productForm").reset();
    $("productId").value = product?.id || "";
    $("productDialogTitle").textContent = product ? "Edit product" : "Add product";
    $("productName").value = product?.name || "";
    $("productPrice").value = product?.price ?? "";
    $("productStock").value = product?.stock ?? 0;
    $("stockEditHint").textContent = product
      ? "Enter the new total stock quantity. This replaces the current available quantity."
      : "Enter the starting quantity available for sale.";
    $("productDialog").showModal();
  }

  function saveProduct(event) {
    event.preventDefault();
    const id = $("productId").value;
    const name = $("productName").value.trim();
    const price = Number($("productPrice").value);
    const stock = Number($("productStock").value);
    if (!name || !Number.isFinite(price) || price < 0 || !Number.isInteger(stock) || stock < 0) {
      showToast("Enter a valid name, price, and whole-number stock quantity.");
      return;
    }
    const duplicate = data.products.some((product) => product.name.toLowerCase() === name.toLowerCase() && product.id !== id);
    if (duplicate) {
      showToast("A product with this name already exists.");
      return;
    }
    if (id) {
      const product = data.products.find((item) => item.id === id);
      if (!product) return;
      product.name = name;
      product.price = price;
      product.stock = stock;
    } else {
      data.products.push({ id: makeId(), name, price, stock });
    }
    saveData();
    $("productDialog").close();
    renderProducts();
    renderDashboard();
    showToast(id ? "Product updated." : "Product added.");
  }

  function deleteProduct(id) {
    const product = data.products.find((item) => item.id === id);
    if (!product) return;
    if (!confirm(`Delete "${product.name}"? Past sales records will remain.`)) return;
    data.products = data.products.filter((item) => item.id !== id);
    cart = cart.filter((item) => item.productId !== id);
    saveData();
    renderProducts();
    renderDashboard();
    showToast("Product deleted.");
  }

  function renderCustomers() {
    const query = $("customerSearch").value.trim().toLowerCase();
    const customers = data.customers.filter((customer) =>
      customer.name.toLowerCase().includes(query) || String(customer.phone || "").toLowerCase().includes(query)
    );
    $("customerCount").textContent = `${customers.length} customer(s)`;
    $("customersTable").innerHTML = customers.length ? tableHTML(
      ["Customer", "Phone", "Total purchases", "Actions"],
      customers.map((customer) => {
        const sales = data.sales.filter((sale) => sale.customerId === customer.id);
        const total = sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);
        return [
          `<strong>${escapeHTML(customer.name)}</strong>`,
          escapeHTML(customer.phone || "—"),
          money(total),
          `<div class="table-actions"><button class="small-action" data-action="customer-details" data-id="${customer.id}">View</button><button class="small-action" data-action="edit-customer" data-id="${customer.id}">Edit</button><button class="small-action delete" data-action="delete-customer" data-id="${customer.id}">Delete</button></div>`
        ];
      })
    ) : emptyHTML("No customers found. Add your first customer.");
  }

  function openCustomerDialog(customer = null) {
    $("customerForm").reset();
    $("customerId").value = customer?.id || "";
    $("customerDialogTitle").textContent = customer ? "Edit customer" : "Add customer";
    $("customerName").value = customer?.name || "";
    $("customerPhone").value = customer?.phone || "";
    $("customerNotes").value = customer?.notes || "";
    $("customerDialog").showModal();
  }

  function saveCustomer(event) {
    event.preventDefault();
    const id = $("customerId").value;
    const name = $("customerName").value.trim();
    if (!name) {
      showToast("Enter the customer's name.");
      return;
    }
    const customer = { name, phone: $("customerPhone").value.trim(), notes: $("customerNotes").value.trim() };
    if (id) Object.assign(data.customers.find((item) => item.id === id), customer);
    else data.customers.push({ id: makeId(), ...customer });
    saveData();
    $("customerDialog").close();
    renderCustomers();
    renderSalePage();
    renderDashboard();
    showToast(id ? "Customer updated." : "Customer added.");
  }

  function deleteCustomer(id) {
    const customer = data.customers.find((item) => item.id === id);
    if (!customer) return;
    if (!confirm(`Delete "${customer.name}"? Existing sales will remain in reports.`)) return;
    data.customers = data.customers.filter((item) => item.id !== id);
    if ($("saleCustomer").value === id) $("saleCustomer").value = "";
    saveData();
    renderCustomers();
    renderSalePage();
    renderDashboard();
    showToast("Customer deleted.");
  }

  function showCustomerDetails(id) {
    const customer = data.customers.find((item) => item.id === id);
    if (!customer) return;
    const sales = data.sales.filter((sale) => sale.customerId === id).sort((a, b) => b.createdAt - a.createdAt);
    const total = sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);
    $("detailTitle").textContent = customer.name;
    $("detailContent").innerHTML = `
      <div class="detail-summary">
        <div><span>Total purchases</span><strong>${money(total)}</strong></div>
        <div><span>Transactions</span><strong>${sales.length}</strong></div>
        <div><span>Phone</span><strong>${escapeHTML(customer.phone || "—")}</strong></div>
      </div>
      ${customer.notes ? `<p class="muted">${escapeHTML(customer.notes)}</p>` : ""}
      ${sales.length ? tableHTML(["Date", "Items", "Amount"], sales.map((sale) => [
        formatDate(sale.date), sale.items.map((item) => `${escapeHTML(item.name)} × ${item.quantity}`).join("<br>"), money(sale.total)
      ])) : emptyHTML("No purchases recorded for this customer.")}`;
    $("detailDialog").showModal();
  }

  function renderSalePage() {
    const selected = $("saleCustomer").value;
    $("saleCustomer").innerHTML = `<option value="">Walk-in customer</option>` + data.customers.map((customer) =>
      `<option value="${customer.id}">${escapeHTML(customer.name)}</option>`).join("");
    $("saleCustomer").value = data.customers.some((customer) => customer.id === selected) ? selected : "";
    const query = $("saleProductSearch").value.trim().toLowerCase();
    const products = data.products.filter((product) => product.name.toLowerCase().includes(query));
    $("saleProductList").innerHTML = products.length ? products.map((product) => `
      <div class="picker-item"><div><strong>${escapeHTML(product.name)}</strong><span>${money(product.price)} · ${product.stock} in stock</span></div>
      <button class="small-action" data-action="add-to-cart" data-id="${product.id}" ${product.stock <= 0 ? "disabled" : ""}>Add</button></div>`).join("") : emptyHTML("No matching products. Add products first.");
    renderCart();
  }

  function addToCart(id) {
    const product = data.products.find((item) => item.id === id);
    if (!product || product.stock <= 0) {
      showToast("This product is out of stock.");
      return;
    }
    const line = cart.find((item) => item.productId === id);
    if (line) {
      if (line.quantity >= product.stock) {
        showToast("You cannot add more than the available stock.");
        return;
      }
      line.quantity += 1;
    } else {
      cart.push({ productId: id, quantity: 1 });
    }
    renderCart();
  }

  function changeCartQuantity(id, amount) {
    const line = cart.find((item) => item.productId === id);
    const product = data.products.find((item) => item.id === id);
    if (!line || !product) return;
    const next = line.quantity + amount;
    if (next <= 0) cart = cart.filter((item) => item.productId !== id);
    else if (next <= product.stock) line.quantity = next;
    else showToast("Quantity cannot exceed available stock.");
    renderCart();
  }

  function renderCart() {
    if (!cart.length) {
      $("cartItems").innerHTML = emptyHTML("Your cart is empty.");
      $("cartTotal").textContent = money(0);
      return;
    }
    let total = 0;
    $("cartItems").innerHTML = cart.map((line) => {
      const product = data.products.find((item) => item.id === line.productId);
      if (!product) return "";
      const lineTotal = Number(product.price) * line.quantity;
      total += lineTotal;
      return `<div class="cart-line"><div><strong>${escapeHTML(product.name)}</strong><small>${money(product.price)} each · ${money(lineTotal)}</small>
        <div class="quantity-controls"><button data-action="cart-minus" data-id="${product.id}" aria-label="Decrease quantity">−</button><span>${line.quantity}</span><button data-action="cart-plus" data-id="${product.id}" aria-label="Increase quantity">＋</button></div></div>
        <button class="small-action delete" data-action="remove-cart" data-id="${product.id}">Remove</button></div>`;
    }).join("");
    $("cartTotal").textContent = money(total);
  }

  function completeSale() {
    if (!cart.length) {
      showToast("Add at least one product to the cart.");
      return;
    }
    for (const line of cart) {
      const product = data.products.find((item) => item.id === line.productId);
      if (!product || product.stock < line.quantity) {
        showToast("Stock changed. Please review your cart.");
        renderSalePage();
        return;
      }
    }
    const items = cart.map((line) => {
      const product = data.products.find((item) => item.id === line.productId);
      product.stock -= line.quantity;
      return {
        productId: product.id, name: product.name, price: Number(product.price),
        quantity: line.quantity, subtotal: Number(product.price) * line.quantity
      };
    });
    const total = items.reduce((sum, item) => sum + item.subtotal, 0);
    data.sales.push({
      id: makeId(), date: todayISO(), createdAt: Date.now(),
      customerId: $("saleCustomer").value || "", items, total
    });
    cart = [];
    saveData();
    renderSalePage();
    renderDashboard();
    showToast("Sale completed and stock updated.");
  }

  function renderReports() {
    if (!$("reportFrom").value) $("reportFrom").value = todayISO().slice(0, 8) + "01";
    if (!$("reportTo").value) $("reportTo").value = todayISO();
    const selectedCustomer = $("reportCustomer").value;
    $("reportCustomer").innerHTML = `<option value="">All customers</option>` + data.customers.map((customer) =>
      `<option value="${customer.id}">${escapeHTML(customer.name)}</option>`).join("");
    $("reportCustomer").value = data.customers.some((customer) => customer.id === selectedCustomer) ? selectedCustomer : "";
    applyReportFilters();
  }

  function getFilteredSales() {
    const from = $("reportFrom").value;
    const to = $("reportTo").value;
    const customerId = $("reportCustomer").value;
    return data.sales.filter((sale) =>
      (!from || sale.date >= from) && (!to || sale.date <= to) &&
      (!customerId || sale.customerId === customerId)
    ).sort((a, b) => b.createdAt - a.createdAt);
  }

  function applyReportFilters() {
    const sales = getFilteredSales();
    const total = sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);
    const items = sales.reduce((sum, sale) => sum + sale.items.reduce((itemSum, item) => itemSum + Number(item.quantity), 0), 0);
    $("reportTotal").textContent = money(total);
    $("reportTransactions").textContent = String(sales.length);
    $("reportItems").textContent = String(items);
    $("reportTable").innerHTML = sales.length ? tableHTML(
      ["Date", "Customer", "Items", "Total", "Receipt"],
      sales.map((sale) => [
        formatDate(sale.date), escapeHTML(getCustomerName(sale.customerId)),
        sale.items.map((item) => `${escapeHTML(item.name)} × ${item.quantity}`).join("<br>"),
        money(sale.total),
        `<button class="small-action" data-action="sale-details" data-id="${sale.id}">View</button>`
      ])
    ) : emptyHTML("No transactions match these filters.");
  }

  function showSaleDetails(id) {
    const sale = data.sales.find((item) => item.id === id);
    if (!sale) return;
    $("detailTitle").textContent = "Sale receipt";
    $("detailContent").innerHTML = `
      <div class="detail-summary"><div><span>Date</span><strong>${formatDate(sale.date)}</strong></div>
      <div><span>Customer</span><strong>${escapeHTML(getCustomerName(sale.customerId))}</strong></div>
      <div><span>Total</span><strong>${money(sale.total)}</strong></div></div>
      ${tableHTML(["Product", "Price", "Quantity", "Subtotal"], sale.items.map((item) => [
        escapeHTML(item.name), money(item.price), item.quantity, money(item.subtotal)
      ]))}
      <div class="cart-total"><span>Grand total</span><strong>${money(sale.total)}</strong></div>
      <button class="primary-button" id="printReceiptBtn">Print receipt</button>`;
    $("detailDialog").showModal();
    $("printReceiptBtn").addEventListener("click", () => printReceipt(sale), { once: true });
  }

  function printReceipt(sale) {
    const receipt = `<!doctype html><html><head><title>Receipt</title><style>body{font:14px Arial;padding:24px;color:#222}h2,p{text-align:center}table{width:100%;border-collapse:collapse;margin-top:20px}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left}.total{text-align:right;font-size:18px;font-weight:bold;margin-top:20px}</style></head><body>
      <h2>${escapeHTML(data.profile.business || "Areev Sales Manager")}</h2><p>Sales receipt</p>
      <p>${formatDate(sale.date)} · ${escapeHTML(getCustomerName(sale.customerId))}</p>
      ${tableHTML(["Product", "Price", "Qty", "Subtotal"], sale.items.map((item) => [escapeHTML(item.name), money(item.price), item.quantity, money(item.subtotal)]))}
      <div class="total">Total: ${money(sale.total)}</div><p>Thank you!</p><script>window.onload=()=>window.print();<\/script></body></html>`;
    const printWindow = window.open("", "_blank", "width=700,height=700");
    if (!printWindow) {
      showToast("Allow pop-ups to print the receipt.");
      return;
    }
    printWindow.document.open();
    printWindow.document.write(receipt);
    printWindow.document.close();
  }

  function renderSettings() {
    $("businessName").value = data.profile.business || "";
    $("ownerName").value = data.profile.name || "";
    $("phoneNumber").value = data.profile.phone || "";
    $("currencyCode").value = data.profile.currency || "INR";
  }

  function saveProfile(event) {
    event.preventDefault();
    data.profile = {
      business: $("businessName").value.trim(),
      name: $("ownerName").value.trim(),
      phone: $("phoneNumber").value.trim(),
      currency: $("currencyCode").value
    };
    saveData();
    renderHeader();
    renderDashboard();
    renderProducts();
    renderCustomers();
    renderSalePage();
    renderReports();
    showToast("Profile saved.");
  }

  function exportBackup() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `areev-sales-backup-${todayISO()}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast("Backup exported.");
  }

  function importBackup(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const imported = JSON.parse(String(reader.result));
        if (!imported || !Array.isArray(imported.products) || !Array.isArray(imported.customers) || !Array.isArray(imported.sales)) {
          throw new Error("Invalid backup structure");
        }
        if (!confirm("Import this backup? It will replace the current app data.")) return;
        data = {
          profile: { ...initialData().profile, ...(imported.profile || {}) },
          products: imported.products,
          customers: imported.customers,
          sales: imported.sales
        };
        saveData();
        cart = [];
        renderAll();
        showToast("Backup imported.");
      } catch (error) {
        showToast("This backup file is not valid.");
      } finally {
        event.target.value = "";
      }
    };
    reader.readAsText(file);
  }

  function resetData() {
    if (!confirm("This will permanently remove all products, customers, sales, and profile details from this browser. Continue?")) return;
    if (!confirm("Please confirm once more: reset all Areev Sales Manager data?")) return;
    data = initialData();
    cart = [];
    saveData();
    renderAll();
    setPage("dashboard");
    showToast("All app data has been reset.");
  }

  function renderAll() {
    renderHeader();
    renderDashboard();
    renderProducts();
    renderCustomers();
    renderSalePage();
    renderReports();
    renderSettings();
  }

  document.querySelectorAll(".nav-link").forEach((button) => {
    button.addEventListener("click", () => setPage(button.dataset.page));
  });
  document.querySelectorAll("[data-go]").forEach((button) => {
    button.addEventListener("click", () => setPage(button.dataset.go));
  });
  $("menuToggle").addEventListener("click", () => $("sidebar").classList.toggle("open"));
  $("profileShortcut").addEventListener("click", () => setPage("settings"));

  $("addProductBtn").addEventListener("click", () => openProductDialog());
  $("productForm").addEventListener("submit", saveProduct);
  $("productSearch").addEventListener("input", renderProducts);
  $("productsTable").addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const product = data.products.find((item) => item.id === button.dataset.id);
    if (button.dataset.action === "edit-product") openProductDialog(product);
    if (button.dataset.action === "delete-product") deleteProduct(button.dataset.id);
  });

  $("addCustomerBtn").addEventListener("click", () => openCustomerDialog());
  $("customerForm").addEventListener("submit", saveCustomer);
  $("customerSearch").addEventListener("input", renderCustomers);
  $("customersTable").addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const customer = data.customers.find((item) => item.id === button.dataset.id);
    if (button.dataset.action === "edit-customer") openCustomerDialog(customer);
    if (button.dataset.action === "delete-customer") deleteCustomer(button.dataset.id);
    if (button.dataset.action === "customer-details") showCustomerDetails(button.dataset.id);
  });

  $("saleProductSearch").addEventListener("input", renderSalePage);
  $("saleProductList").addEventListener("click", (event) => {
    const button = event.target.closest('[data-action="add-to-cart"]');
    if (button) addToCart(button.dataset.id);
  });
  $("cartItems").addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const id = button.dataset.id;
    if (button.dataset.action === "cart-minus") changeCartQuantity(id, -1);
    if (button.dataset.action === "cart-plus") changeCartQuantity(id, 1);
    if (button.dataset.action === "remove-cart") {
      cart = cart.filter((item) => item.productId !== id);
      renderCart();
    }
  });
  $("completeSaleBtn").addEventListener("click", completeSale);
  $("clearCartBtn").addEventListener("click", () => { cart = []; renderCart(); });
  $("saleCustomer").addEventListener("change", () => {});

  $("applyReportBtn").addEventListener("click", applyReportFilters);
  $("reportTable").addEventListener("click", (event) => {
    const button = event.target.closest('[data-action="sale-details"]');
    if (button) showSaleDetails(button.dataset.id);
  });
  $("printReportBtn").addEventListener("click", () => window.print());
  $("profileForm").addEventListener("submit", saveProfile);
  $("exportDataBtn").addEventListener("click", exportBackup);
  $("importDataInput").addEventListener("change", importBackup);
  $("resetDataBtn").addEventListener("click", resetData);

  document.querySelectorAll("[data-close]").forEach((button) => {
    button.addEventListener("click", () => $(button.dataset.close).close());
  });

  renderAll();
})();